//----------------------------------------------------------------------------------------------------;

(function(){


var THTML0 = `
<style>
a { color: #FFFFFF }
th, td { border: none !important; text-align: center; font-size: 11px; }
body { overflow-x: none; background-color: black; color: #ffffff; } img { padding: 0px !important; border: none !important; } ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background-color: lightblue; } ::-webkit-scrollbar-track-piece { background-color: gray; } ::-webkit-scrollbar-thumb { border-radius: 8px; background-color: white; } ::-webkit-scrollbar-button { background-color: darkblue; width: 20px; height: 10px; } ::-webkit-scrollbar-button:start { background-color: red; } ::-webkit-scrollbar-button:end { background-color: orange; } ::-webkit-scrollbar-button:vertical:increment {} ::-webkit-scrollbar-button:vertical:decrement {} ::-webkit-scrollbar-corner { background-color: violet; } ::-webkit-resizer { background-color: green; }
.divContainer { position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; }

.td0 { width: 49px; }
.td1 { width: 150px; }
.td2 { width: 47px; }
.td4 { width: 60px; }

.pb0{ color: #2141de; } .pb{ color: #3498eb; } .pr { color: #FF0000; }
.aa0 { color: #d2ff78; } .aa1 { color: #f4ff78; }
.aa2 { color: #ffef78; } .aa3 { color: #ffd078; }
.aa4 { color: #ffac78; } .aa5 { color: #ff8f78; }
.aa6 { color: #ff7878; } .aa7 { color: #ff3030; }
</style>
<div>
	<audio id="ID-AUDIO" controls style="display: none;"><source id="ID-AUDIO_SRC" src="" type="audio/mpeg"></audio>
	<div style="padding: 5px;">
		<div>종목명 | 등락률(저) | 등락률 | 등락률(고) | 거래대금</div>
		<div>색상 강도 : <span style="color: #d2ff78;">연두</span> → <span style="color: #ffef78;">노랑</span> → <span style="color: #ffac78;">주황</span> → <span style="color: #ff3030;">빨강</div>
		<div></div>
	</div>
	<div id="ID-TextCards" style="display: flex; flex-wrap: wrap;"></div>
</div>
`;

window.document.body.children[ 2 ].innerHTML = THTML0;



(function(){
	/*/
	var THTML = `<table border="solid 1px; margin-left: 5px;">
		<tbody>
			<tr id="{{종목코드}}">
				<td></td>
				<td class="td1">{{종목이름}}</td>
				<td class="td2"></td>
				<td class="td2"></td>
				<td class="td2"></td>
				<td class="td4"></td>
			</tr>
		</tbody>
	</table>`;
	//<td class="td0"></td> - 시간;
	/*/
	var THTML = `<table border="solid 1px; margin-left: 5px;"><tbody><tr id="{{종목코드}}"><td></td><td class="td1">{{종목이름}}</td><td class="td2"></td><td class="td2"></td><td class="td2"></td><td class="td4"></td></tr></tbody></table>`;
	//<td class="td0"></td> - 시간;
	//*/

	/*/
	var THTML = `<table border="solid 1px; margin-left: 5px;">
		<tbody>
			<tr>
				<td colspan="5">{{종목이름}}</td>
			</tr>
			<tr id="{{종목코드}}">
				<td></td>
				<td class="td2"></td>
				<td class="td2"></td>
				<td class="td2"></td>
				<td class="td4"></td>
			</tr>
		</tbody>
	</table>`;
	//*/



	var el = window.document.getElementById( "ID-TextCards" );

	/*/
	//var xhr = SUtilXMLHttpReqGet.reqSyncReturn( "file:///E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--AllTimeCharts/data/list-all.json" );
	var xhr = SUtilXMLHttpReqGet.reqSyncReturn( "http://localhost:49323/json/stock/list-all.json" );
	//var xhr = SUtilXMLHttpReqGet.reqSyncReturn( "http://thdtjsdn.com/json/stock/list-all.json" );
	var resText = xhr.responseText;
	/*/
	var resText = SUtilFsReadStream.getFile( "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--AllTimeCharts/data/list-all.json" ).toString();
	//*/
	var div = window.document.createElement( "DIV" );
	var json = JSON.parse( resText );
		json.forEach(function( item ){
			var html = THTML.replace( "{{종목이름}}", item.name )
				.replace( "{{종목코드}}", item.code );
				//.replace( "{{종목코드}}", item.name );
			div.innerHTML = html;
			el.appendChild( div.children[ 0 ] );
		});
})();

})();

//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;

global.REQUIRES = global.REQUIRES || {};
global.REQUIRES.fs = global.REQUIRES.fs || require( "fs" );

//----------------------------------------------------------------------------------------------------;

var PATH000 = "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--AllTimeCharts/data/";

var PATH001 = "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--SelectedChartList-RT/";

//----------------------------------------------------------------------------------------------------;

//var URL = "https://polling.finance.naver.com/api/realtime.nhn?_callback=&query=SERVICE_ITEM%3A";
var URL = "https://polling.finance.naver.com/api/realtime?_callback=&query=SERVICE_ITEM%3A";

var A = JSON.parse( SUtilFsReadStream.getFile( PATH000 + "list-all.json" ).toString() );
	A.forEach( function( item ){
		item.url = URL + item.code;
		item.last_cr = null;

//음성 재생;
//		//item.path_mp3 = "file:///" + PATH001 + "./root/mp3/stock_nm/" + item.name + ".mp3";
//		item.path_mp3 = "./mp3/stock_nm/" + item.name + ".mp3";
//
//		var t = '<audio controls style="display: none;"><source src="' + item.path_mp3 + '" type="audio/mpeg"></audio>'
//		item.el_audio = SUtilTemplateHTML.createHTML( t );
//		window.document.body.appendChild( item.el_audio );
	});

var XHRS = [
	new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
];

//----------------------------------------------------------------------------------------------------;

var I = {
	i : 0
	, iLen : A.length
	, io : A[ 0 ]
};

//----------------------------------------------------------------------------------------------------;

var FN = function( xhr ){

	if( I.i == I.iLen )
	{
		I.i = 0;
		I.io = A[ I.i ];

		FN.UPLOAD_SERVER();
	}

	try
	{
		var fStr = SUtilXMLHttpReqGetRef.reqSyncReturn( xhr, I.io.url ).response;
	}
	catch( er )
	{
		setTimeout( FN, 1 );
		return;
	}

	try
	{
		var fJSON = JSON.parse( fStr ).result.areas[ 0 ].datas[ 0 ];
	}
	catch( er )
	{
		setTimeout( FN, 1 );
		return;
	}

	try
	{
		var lvp = ( ( fJSON.lv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );
		var hvp = ( ( fJSON.hv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );
	}
	catch( er )
	{
		setTimeout( FN, 1 );
		return;
	}

	if( fJSON.rf == 5 ) fJSON.cr = -fJSON.cr;

	var cr = fJSON.cr;
	var crl = lvp;
	var crh = hvp;
	var dt = new Date().toTimeString().slice( 0, 8 );

		try
		{
			//if( FN.lastEl ) FN.lastEl.style.border = "";
			var el = window.document.getElementById( fJSON.cd );
				//el.style.border = "1px solid #ffef78";
				//el.children[ 0 ].innerText = dt;

				//*/
				var el_crl = el.children[ 2 ];
				var el_cr  = el.children[ 3 ];
				var el_crh = el.children[ 4 ];
				var el_aa  = el.children[ 5 ];
				/*/
				var el_crl = el.children[ 1 ];
				var el_cr  = el.children[ 2 ];
				var el_crh = el.children[ 3 ];
				var el_aa  = el.children[ 4 ];
				//*/

				/*/
				     if( crl > 0 ) el_crl.innerHTML = '<span class="pr">' + crl + "%</span>";
				else if( crl < 0 ) el_crl.innerHTML = '<span class="pb">' + crl + "%</span>";
				else el_crl.innerText = crl + "%";

				     if( cr > 0 ) el_cr.innerHTML = '<span class="pr">' + cr + "%</span>";
				else if( cr < 0 ) el_cr.innerHTML = '<span class="pb">' + cr + "%</span>";
				else el_cr.innerText = cr + "%";

				     if( crh > 0 ) el_crh.innerHTML = '<span class="pr">' + crh + "%</span>";
				else if( crh < 0 ) el_crh.innerHTML = '<span class="pb">' + crh + "%</span>";
				else el_crh.innerText = crh + "%";
				//*/

				/*/
				     if( crl > 0 ) el_crl.innerHTML = '<span class="pr">' + crl + "</span>";
				else if( crl < 0 ) el_crl.innerHTML = '<span class="pb">' + crl + "</span>";
				else el_crl.innerText = crl + "%";

				     if( cr > 0 ) el_cr.innerHTML = '<span class="pr">' + cr + "</span>";
				else if( cr < 0 ) el_cr.innerHTML = '<span class="pb">' + cr + "</span>";
				else el_cr.innerText = cr + "%";

				     if( crh > 0 ) el_crh.innerHTML = '<span class="pr">' + crh + "</span>";
				else if( crh < 0 ) el_crh.innerHTML = '<span class="pb">' + crh + "</span>";
				else el_crh.innerText = crh + "%";
				//*/

				//*/
				if( crl < 0 )
				{
					if( crl < -9 ) el_crl.innerHTML = '<span class="pb0">' + crl + "</span>";
					else el_crl.innerHTML = '<span class="pb">' + crl + "</span>";
				}
				else if( crl > 0 )
				{
					     if( crl > 24 ) el_crl.innerHTML = '<span class="pr" >' + crl + "</span>";
					else if( crl > 21 ) el_crl.innerHTML = '<span class="aa7">' + crl + "</span>";
					else if( crl > 18 ) el_crl.innerHTML = '<span class="aa6">' + crl + "</span>";
					else if( crl > 15 ) el_crl.innerHTML = '<span class="aa5">' + crl + "</span>";
					else if( crl > 12 ) el_crl.innerHTML = '<span class="aa4">' + crl + "</span>";
					else if( crl >  9 ) el_crl.innerHTML = '<span class="aa3">' + crl + "</span>";
					else if( crl >  6 ) el_crl.innerHTML = '<span class="aa2">' + crl + "</span>";
					else if( crl >  3 ) el_crl.innerHTML = '<span class="aa1">' + crl + "</span>";
					else if( crl >  0 ) el_crl.innerHTML = '<span class="aa0">' + crl + "</span>";
				}
				else el_crl.innerText = crl + "%";

				if( cr < 0 )
				{
					if( cr < -9 ) el_cr.innerHTML = '<span class="pb0">' + cr + "</span>";
					else el_cr.innerHTML = '<span class="pb">' + cr + "</span>";
				}
				else if( cr > 0 )
				{
					     if( cr > 24 ) el_cr.innerHTML = '<span class="pr" >' + cr + "</span>";
					else if( cr > 21 ) el_cr.innerHTML = '<span class="aa7">' + cr + "</span>";
					else if( cr > 18 ) el_cr.innerHTML = '<span class="aa6">' + cr + "</span>";
					else if( cr > 15 ) el_cr.innerHTML = '<span class="aa5">' + cr + "</span>";
					else if( cr > 12 ) el_cr.innerHTML = '<span class="aa4">' + cr + "</span>";
					else if( cr >  9 ) el_cr.innerHTML = '<span class="aa3">' + cr + "</span>";
					else if( cr >  6 ) el_cr.innerHTML = '<span class="aa2">' + cr + "</span>";
					else if( cr >  3 ) el_cr.innerHTML = '<span class="aa1">' + cr + "</span>";
					else if( cr >  0 ) el_cr.innerHTML = '<span class="aa0">' + cr + "</span>";
				}
				else el_cr.innerText = cr + "%";

				if( crh < 0 )
				{
					if( crh < -9 ) el_crh.innerHTML = '<span class="pb0">' + crh + "</span>";
					else el_crh.innerHTML = '<span class="pb">' + crh + "</span>";
				}
				else if( crh > 0 )
				{
					     if( crh > 24 ) el_crh.innerHTML = '<span class="pr" >' + crh + "</span>";
					else if( crh > 21 ) el_crh.innerHTML = '<span class="aa7">' + crh + "</span>";
					else if( crh > 18 ) el_crh.innerHTML = '<span class="aa6">' + crh + "</span>";
					else if( crh > 15 ) el_crh.innerHTML = '<span class="aa5">' + crh + "</span>";
					else if( crh > 12 ) el_crh.innerHTML = '<span class="aa4">' + crh + "</span>";
					else if( crh >  9 ) el_crh.innerHTML = '<span class="aa3">' + crh + "</span>";
					else if( crh >  6 ) el_crh.innerHTML = '<span class="aa2">' + crh + "</span>";
					else if( crh >  3 ) el_crh.innerHTML = '<span class="aa1">' + crh + "</span>";
					else if( crh >  0 ) el_crh.innerHTML = '<span class="aa0">' + crh + "</span>";
				}
				else el_crh.innerText = crh + "%";
				//*/

				//el_aa.innerText = FN.addComma( fJSON.aa );
				var aaStr = fJSON.aa.toString();

				/*/
					 if( aaStr.length ==  6 ) el_aa.innerHTML = '<span class="aa0">' + aaStr[ 0 ] + "십</span>";
				else if( aaStr.length ==  7 ) el_aa.innerHTML = '<span class="aa1">' + aaStr[ 0 ] + "백</span>";
				else if( aaStr.length ==  8 ) el_aa.innerHTML = '<span class="aa2">' + aaStr[ 0 ] + "천</span>";
				else if( aaStr.length ==  9 ) el_aa.innerHTML = '<span class="aa3">' + aaStr[ 0 ] + "억</span>";
				else if( aaStr.length == 10 ) el_aa.innerHTML = '<span class="aa4">' + aaStr[ 0 ] + "." + aaStr[ 1 ] + "억</span>";
				else if( aaStr.length == 11 ) el_aa.innerHTML = '<span class="aa5">' + aaStr.slice( 0, 2 ) + "." + aaStr[ 2 ] + "억</span>";
				else if( aaStr.length == 12 ) el_aa.innerHTML = '<span class="aa6">' + aaStr.slice( 0, 3 ) + "." + aaStr[ 3 ] + "억</span>";
				else if( aaStr.length == 13 ) el_aa.innerHTML = '<span class="aa7">' + aaStr[ 0 ] + "조</span>";
				else if( aaStr.length == 14 ) el_aa.innerHTML = '<span class="pr">' + aaStr[ 0 ] + "." + aaStr[ 1 ] + "조</span>";
				/*/
					 if( aaStr.length ==  6 ) el_aa.innerHTML = '<span class="aa0">' + aaStr[ 0 ] + "십</span>";
				else if( aaStr.length ==  7 ) el_aa.innerHTML = '<span class="aa1">' + aaStr[ 0 ] + "백</span>";
				else if( aaStr.length ==  8 ) el_aa.innerHTML = '<span class="aa2">' + aaStr[ 0 ] + "천</span>";
				else if( aaStr.length ==  9 ) el_aa.innerHTML = '<span class="aa3">' + aaStr[ 0 ] + "억</span>";
				else if( aaStr.length == 10 ) el_aa.innerHTML = '<span class="aa4">' + aaStr[ 0 ] + "" + aaStr[ 1 ] + "억</span>";
				else if( aaStr.length == 11 ) el_aa.innerHTML = '<span class="aa5">' + aaStr.slice( 0, 2 ) + "" + aaStr[ 2 ] + "억</span>";
				else if( aaStr.length == 12 ) el_aa.innerHTML = '<span class="aa6">' + aaStr.slice( 0, 3 ) + "" + aaStr[ 3 ] + "억</span>";
				else if( aaStr.length == 13 ) el_aa.innerHTML = '<span class="aa7">' + aaStr[ 0 ] + "조</span>";
				else if( aaStr.length == 14 ) el_aa.innerHTML = '<span class="pr">' + aaStr[ 0 ] + "" + aaStr[ 1 ] + "조</span>";
				el_aa.setAttribute( "data-aa", fJSON.aa );
				//*/

				//el.style.border = "";
		}
		catch( er )
		{
		}



	//if( fJSON.rf == 5 ) fJSON.cr = -fJSON.cr;
	//else if( fJSON.rf == 2 )

	if( !I.io.last_aa ) I.io.last_aa = fJSON.aa;
	if( !I.io.last_cr ) I.io.last_cr = fJSON.cr;
	if( !I.io.last_cr0 ) I.io.last_cr0 = fJSON.cr;

	var gab_aa  = fJSON.aa - I.io.last_aa;
	var gab_cr  = fJSON.cr - I.io.last_cr;
	var gab_cr0 = fJSON.cr - I.io.last_cr0;

	//console.log( gab_cr );

	//if( gab_cr > 0.4 )
	//if( gab_cr > 0.5 )
	//if( gab_cr > 1 )
	//if( gab_cr > 1.1 )
	if( gab_cr > 1.1 || gab_cr0 > 1.1 )
	//if( gab_cr > 1 || gab_cr < -1 || gab_cr0 > 1 || gab_cr0 < -1 )
	//if( gab_cr > 1.1 || gab_cr < -1.1 || gab_cr0 > 1.1 || gab_cr0 < -1.1 )
	//if( gab_cr > 1.1 || gab_cr < -1.1 || gab_cr0 > 1.1 || gab_cr0 < -1.1 || gab_aa > 1500000000 )
	{
		//el.style.border = "1px solid #ff8f78";
		FN.lastEl = el;
//음성 재생;
//		try
//		{
//			FN.lastAudio.pause();
//			FN.lastAudio.currentTime = 0;
//		}
//		catch( er )
//		{
//		}
//
//		FN.lastAudio = I.io.el_audio;
//
//		//if( global.REQUIRES.fs.existsSync( I.io.path_mp3 ) ){
//
//			//FN.el_audio_src = I.io.path_mp3;
//			try{
//				//FN.el_audio.pause();
//				//FN.el_audio.currentTime = 0;
//
//				//FN.el_audio.load();
//				//FN.el_audio.play();
//
//				I.io.el_audio.play();
//			}
//			catch( er ){
//				//debugger;
//			}
//		//}

		fJSON.t = Date.now();

		//var lvp = ( ( fJSON.lv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );
		//var hvp = ( ( fJSON.hv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );

		/*/
		var tempFunc = function( e ){};var tempObj = {};var reqParam = { "onload" : tempFunc, "onloadend" : tempFunc };
		var txt = "1607179160788 - 아이큐어 - 0% - 0% - 0%";
		SUtilXMLHttpReqPost.req__paramsStr( "http://thdtjsdn.com/upload__voice_history_1line", txt, tempObj, reqParam );

		var tempFunc = function( e ){};var tempObj = {};var reqParam = { "onload" : tempFunc, "onloadend" : tempFunc };
		var txt = "1607179160788 - 아이큐어 - 1% - 1% - 1%";
		SUtilXMLHttpReqPost.req__paramsStr( "http://thdtjsdn.com/upload__voice_history_1line", txt, tempObj, reqParam );
		//*/
		var txt = "\n" + fJSON.t + " - " + fJSON.nm + " - " + fJSON.cr.toFixed(2) + "%" + " - " + lvp + "%" + " - " + hvp + "%" + " - " + fJSON.aa;
		SUtilXMLHttpReqPost.req__paramsStr( "http://thdtjsdn.com/upload__voice_history_1line", txt, FN.tempObj, FN.reqParam );

		//console.log( txt );
		global.REQUIRES.fs.appendFileSync( "D:/_/__음성히스토리.txt", txt );
	}

	if( I.io.last_cr != fJSON.cr )
	{
		if( I.io.last_cr != I.io.last_cr0 )
		{
			I.io.last_cr0 = I.io.last_cr;
		}

		I.io.last_cr = fJSON.cr;
	}
	else if( I.io.last_cr == fJSON.cr )
	{
		I.io.last_cr = fJSON.cr;
		I.io.last_cr0 = I.io.last_cr;
	}

	++I.i;
	I.io = A[ I.i ];

	setTimeout( FN, 1 );
};
FN.lastAudio = null;
FN.tempFunc = function( e ){};
FN.tempObj = {};
FN.reqParam = { "onload" : FN.tempFunc, "onloadend" : FN.tempFunc };
FN.addComma = function( n ){ var regexp = /\B(?=(\d{3})+(?!\d))/g; return n.toString().replace(regexp, ','); };
FN.lastEl = null;

var FN_UPLOAD_HTML = (function(){
	var url = "http://thdtjsdn.com/upload__html?nm=";
	//var url = "http://localhost:49781/upload__html?nm=1";
	var tempFunc = function( e ){};
	var tempObj = {};
	var reqParam = { "onload" : tempFunc, "onloadend" : tempFunc };
	var fn = function( nm, html ){
		SUtilXMLHttpReqPost.req__paramsStr( url + window.apis.uri.getURIReplaceSharp( nm ) , html, tempObj, reqParam ); };
	return fn;
})();
FN.HTML_HEAD = `<head><META http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>`;
FN.pad = function( n ){ var s = n.toString(); if( s.length == 1 ) return "0" + s; return s; };
FN.UPLOAD_SERVER = function(){ var a = SUtilDate.getDate__Date_Array(); FN_UPLOAD_HTML( a[ 0 ] + FN.pad( a[ 1 ] ) + FN.pad( a[ 2 ] ) +  + " - 전종목 시세", FN.HTML_HEAD + window.document.body.children[ 2 ].innerHTML ); };


//----------------------------------------------------------------------------------------------------;

FN( XHRS[ 0 ] );
FN( XHRS[ 1 ] );
FN( XHRS[ 2 ] );
//FN( XHRS[ 3 ] );
//FN( XHRS[ 4 ] );

//----------------------------------------------------------------------------------------------------;

(function(){
	window.addEventListener( "keydown", function( e ){
		if( e.ctrlKey && e.keyCode == 83 )
		{
			var a = SUtilDate.getDate__Date_Array();
			var fNm = a[ 0 ] + FN.pad( a[ 1 ] ) + FN.pad( a[ 2 ] ) + " - 전종목 시세 - TABLE";
			//FN_UPLOAD_HTML( fNm, FN.HTML_HEAD + window.document.body.children[ 2 ].innerHTML );
			SUtilFsWriteStream.writeFile_UTF8( "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--AllTimeCharts/data/html/__전종목 시세/" + fNm + ".html", FN.HTML_HEAD + window.document.body.children[ 2 ].innerHTML );
		}
	});
})();

//----------------------------------------------------------------------------------------------------;