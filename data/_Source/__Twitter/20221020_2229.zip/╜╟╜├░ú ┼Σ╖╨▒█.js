실시간 토론글 켜놨음

- 실시간 토론 글
 http://thdtjsdn.com/ui/Page/%EC%A3%BC%EC%8B%9D-%ED%86%A0%EB%A1%A0--%EC%8B%A4%EC%8B%9C%EA%B0%84/index.html

- 실시간 토론 글 음성읽어주기(구글 크롬 재생)
 http://thdtjsdn.com/html/page/%EC%A3%BC%EC%8B%9D-%ED%86%A0%EB%A1%A0--%EC%8B%A4%EC%8B%9C%EA%B0%84--%EC%9D%8C%EC%84%B1/index.html

#thdtjsdn #주식 #NASDAQ #BTC