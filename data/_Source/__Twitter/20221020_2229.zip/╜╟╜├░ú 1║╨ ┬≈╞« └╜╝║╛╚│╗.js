- BTC 1분차트 실시간 음성안내(내가 켤때만 구동)
http://thdtjsdn.com/html/vcurrency-index-RealTime--BTC/index--only_voice.html


- NASDAQ 100 선물 1분 차트 실시간 음성 알림(24시간 풀구동)
http://thdtjsdn.com/html/stock-index-RealTime--US--Nas100-MM/index--only_voice.html

#thdtjsdn #주식 #NASDAQ #BTC