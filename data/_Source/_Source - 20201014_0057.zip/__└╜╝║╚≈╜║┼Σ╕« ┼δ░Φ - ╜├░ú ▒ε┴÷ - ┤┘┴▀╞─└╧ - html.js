//----------------------------------------------------------------------------------------------------;

global.REQUIRES = global.REQUIRES || {};
global.REQUIRES.fs = global.REQUIRES.fs || require( "fs" );

//----------------------------------------------------------------------------------------------------;

var PATH = "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--SelectedChartList-RT--Data - 방송/";

//----------------------------------------------------------------------------------------------------;

var pad3 = function( n ){
	var s = n.toString();
	if( s.length == 1 ) return "00" + s;
	if( s.length == 2 ) return "0" + s;
	return s;
};

var pad2 = function( n ){
	var s = n.toString();
	if( s.length == 1 ) return "0" + s;
	return s;
};

var FN = function( num ){

	try
	{
		//var fStr = SUtilFsReadStream.getFile( "d:/_/__음성히스토리 - " + num + ".txt" ).toString();
		var fStr = SUtilFsReadStream.getFile( "d:/_/__음성히스토리" + num + ".txt" ).toString();
	}
	catch( er )
	{
		//var fStr = SUtilFsReadStream.getFile( "d:/_/음성 기록 - " + num + ".txt" ).toString();
		var fStr = SUtilFsReadStream.getFile( "d:/_/음성 기록" + num + ".txt" ).toString();
	}


	//SUtilFsWriteStream.writeFile_UTF8( PATH + "음성 기록 - " + num + ".txt", fStr );

	//fStr = fStr.replace( /.*\ \-\ /gi, "" );

	//----------------------------------------------------------------------------------------------------;

	var T = {};
	var R = {};
	var C = {};
	var LV = {};
	var HV = {};

	var a = fStr.split( "\n" );
		a.forEach(function( item ){

			var aa = item.split( " - " );

			var t = aa[ 0 ];
			var nm = aa[ 1 ];
			var cr = aa[ 2 ];

			var lv = aa[ 3 ];
			var hv = aa[ 4 ];

			if( R[ nm ] )
			{
				++R[ nm ];
				T[ nm ] = t;
				C[ nm ] = cr;
				LV[ nm ] = lv;
				HV[ nm ] = hv;
			}
			else
			{
				R[ nm ] = 1;
				T[ nm ] = t;
				C[ nm ] = cr;
				LV[ nm ] = lv;
				HV[ nm ] = hv;
			}
		});

	var A = [];

	for( var s in R )
	{
		//A.push({ nm : s, cnt : R[ s ] });
		A.push({ nm : s, cnt : R[ s ], cr : C[ s ], lv: LV[ s ] || "0", hv : HV[ s ] || "0", dt : Number( T[ s ] ) });
	}

	A = window.apis.array_collection.sortJsonArrayByKey_Desc( A, "cnt" );

	//A = window.apis.array_collection.sortJsonArrayByKey_Desc( A, "dt" );

	//JSON.stringify( A, null, "\t" );

	//A;

	//----------------------------------------------------------------------------------------------------;

	//SUtilFsWriteStream.writeFile_JSON_Tab1_UTF8( PATH + "음성 기록 통계 - " + num + ".json", A );
	SUtilFsWriteStream.writeFile_JSON_Tab1_UTF8( PATH + "음성 기록 통계" + num + ".json", A );

	var RR = STYLE0 + _THTML0;
	A.forEach(function( item ){

		try
		{
			//var dt = new Date( Number( T[ item.nm ] ) );

			var cr = Number( item.cr.replace( "%", "" ) );

			//if( item.cnt > 10 )
			//if( item.cnt > 50 )
			//if( item.cnt > 80 )
			//if( item.cnt > 100 )
			//if( item.cnt > 150 )
			//if( item.cnt > 200 )
			//if( item.cnt > 300 )
			//if( cr > 3 && item.cnt > 50 )
			//if( cr > 3 && item.cnt > 150 )
			//if( cr > 10 && item.cnt > 50 )
			//if( cr > 10 && item.cnt > 150 )
			//if( cr > 20 && item.cnt > 100 )

			if( item.nm != "undefined"
				&& item.nm != undefined
				&& item.nm != "{{nm}}"
			)
			{
				if( -1 == item.cr.indexOf( "-" ) ) item.cr = "+" + item.cr;
				if( -1 == item.hv.indexOf( "-" ) ) item.hv = "+" + item.hv;
				if( -1 == item.lv.indexOf( "-" ) ) item.lv = "+" + item.lv;

				var dt = new Date( item.dt );
				item.dt = pad2( dt.getHours() ) + ":" + pad2( dt.getMinutes() ) + ":" + pad2( dt.getSeconds() );

				item.hlv = Number( item.hv.replace( "%", "" ) ) - Number( item.lv.replace( "%", "" ) );
				item.hlv = item.hlv.toFixed( 2 ) + "%";

				item.KEY = KEY;
				RR += "\n" + SUtilString.applyBraceStrFromObj( _THTML2, item );
			}
		}
		catch( er )
		{
			//debugger;
			console.log( item.nm + " - " + er );
		}
	});
	RR += _THTML1;

	var dtc = new Date();
		dtc = dtc.getFullYear() + "." + pad2( dtc.getMonth() + 1 ) + "." + pad2( dtc.getDate() ) + " " + pad2( dtc.getHours() ) + ":" + pad2( dtc.getMinutes() ) + ":" + pad2( dtc.getSeconds() );
		dtc = dtc.replace( /\:/gi, "ː");

	//SUtilFsWriteStream.writeFile_UTF8( PATH + dtc + " - 음성 기록 통계 - " + num + ".html", RR );
	SUtilFsWriteStream.writeFile_UTF8( PATH + dtc + " - 음성 기록 통계" + num + ".html", RR );
};

//----------------------------------------------------------------------------------------------------;

var _THTML0 = `
<div dir="ltr" style="text-align: left;" trbidi="on">
<table style="width: 100%; table-layout: fixed; text-align: center;">
<thead>
<tr>
<th style="width: 50px;">횟수</th>
<th style="width: 70px;">시간</th>
<th style="width: 130px;">종목명</th>
<th style="width: 70px;">등락률</th>
<th style="width: 70px;">등락(저)</th>
<th style="width: 70px;">등락(고)</th>
<th style="width: 70px;">고저 차이</th>
<th style="width: 100%;">비고</th>
</tr>
</thead>
<tbody>`;

var _THTML1 = `</tbody></table></div>`;


var KEY = "asfasfaf";

var _THTML2 = `<tr>
<td>{{cnt}}</td>
<td>{{dt}}</td>
<td><a href="http://thdtjsdn.shop:49781/img/stock/charts/{{KEY}}/{{nm}}.png" target="_blank">{{nm}}</a></td>
<td><a href="http://thdtjsdn.shop:49781/img/stock/charts-kiwoom/{{KEY}}/{{nm}}.png" target="_blank">{{cr}}</a></td>
<td><a href="http://thdtjsdn.shop:49781/img/stock/charts-kiwoom-uhd/{{KEY}}/{{nm}}.png" target="_blank">{{lv}}</a></td>
<td>{{hv}}</td>
<td>{{hlv}}</td>
<td></td>
</tr>`;

var STYLE0 = `<head>
<META http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<style>
body{ background-color: black; overflow-x: hidden; color: white; }<style>
table { width: 100%; border: 1px solid #444444; }
a {
	color: #ffffff;
}
th, td {
	font-size: 12px;
	border: 1px solid #444444;

	text-overflow:ellipsis;
	white-space:nowrap;
	word-wrap:normal;
	overflow:hidden;

	cursor: pointer;
}
</style>
</head><body><br/>광고 좀 클릭 해주세요.(서버 비용은 공짜가 아닙니다.)`

//----------------------------------------------------------------------------------------------------;


FN( "" );
//FN( "0.5" );
//FN( "0.7" );
//FN( "-0.7" );
//FN( "1" );
//FN( "-1" );
//FN( "2" );
//FN( "-2" );
//FN( "3" );
//FN( "-3" );