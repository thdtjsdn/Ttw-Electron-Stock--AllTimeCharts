전세계 1일 - http://thdtjsdn.com/index--stock-chart-global-index--today.html

전세계 일봉 - http://thdtjsdn.com/index--stock-chart-global-index--day.html

주요국 1일 - http://thdtjsdn.com/index--stock-chart-global-index---st0--today.html

주요국 일봉 - http://thdtjsdn.com/index--stock-chart-global-index---st0--day.html

#thdtjsdn #주식 #NASDAQ #DOW