//----------------------------------------------------------------------------------------------------;

global.REQUIRES = global.REQUIRES || {};
global.REQUIRES.fs = global.REQUIRES.fs || require( "fs" );

//----------------------------------------------------------------------------------------------------;

var PATH000 = "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--AllTimeCharts/data/";

var PATH001 = "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--SelectedChartList-RT/";

//----------------------------------------------------------------------------------------------------;

var URL = "https://polling.finance.naver.com/api/realtime.nhn?_callback=&query=SERVICE_ITEM%3A";

var A = JSON.parse( SUtilFsReadStream.getFile( PATH000 + "list-all.json" ).toString() );
	A.forEach( function( item ){
		item.url = URL + item.code;
		item.last_cr = null;

//음성 재생;
//		//item.path_mp3 = "file:///" + PATH001 + "./root/mp3/stock_nm/" + item.name + ".mp3";
//		item.path_mp3 = "./mp3/stock_nm/" + item.name + ".mp3";
//
//		var t = '<audio controls style="display: none;"><source src="' + item.path_mp3 + '" type="audio/mpeg"></audio>'
//		item.el_audio = SUtilTemplateHTML.createHTML( t );
//		window.document.body.appendChild( item.el_audio );
	});

var XHRS = [
	new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
	, new XMLHttpRequest()
];

//----------------------------------------------------------------------------------------------------;

var I = {
	i : 0
	, iLen : A.length
	, io : A[ 0 ]
};

//----------------------------------------------------------------------------------------------------;

var FN = function( xhr ){

	if( I.i == I.iLen )
	{
		I.i = 0;
		I.io = A[ I.i ];
	}

	var fStr = SUtilXMLHttpReqGetRef.reqSyncReturn( xhr, I.io.url ).response;
	var fJSON = JSON.parse( fStr ).result.areas[ 0 ].datas[ 0 ];

	if( fJSON.rf == 5 ) fJSON.cr = -fJSON.cr;
	//else if( fJSON.rf == 2 )

	if( !I.io.last_cr ) I.io.last_cr = fJSON.cr;

	var gab_cr = fJSON.cr - I.io.last_cr;

	//console.log( gab_cr );

	if( gab_cr > 0.4 )
	//if( gab_cr > 0.5 )
	{

//음성 재생;
//		try
//		{
//			FN.lastAudio.pause();
//			FN.lastAudio.currentTime = 0;
//		}
//		catch( er )
//		{
//		}
//
//		FN.lastAudio = I.io.el_audio;
//
//		//if( global.REQUIRES.fs.existsSync( I.io.path_mp3 ) ){
//
//			//FN.el_audio_src = I.io.path_mp3;
//			try{
//				//FN.el_audio.pause();
//				//FN.el_audio.currentTime = 0;
//
//				//FN.el_audio.load();
//				//FN.el_audio.play();
//
//				I.io.el_audio.play();
//			}
//			catch( er ){
//				//debugger;
//			}
//		//}

		fJSON.t = Date.now();

		var lvp = ( ( fJSON.lv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );
		var hvp = ( ( fJSON.hv - fJSON.pcv ) / fJSON.pcv * 100 ).toFixed( 2 );
		var txt = "\n" + fJSON.t + " - " + fJSON.nm + " - " + fJSON.cr.toFixed(2) + "%" + " - " + lvp + "%" + " - " + hvp + "%";

		SUtilXMLHttpReqPost.req__paramsStr( "http://thdtjsdn.com/upload__voice_history_1line", txt, FN.tempObj, FN.reqParam );

		//console.log( txt );
		global.REQUIRES.fs.appendFileSync( "D:/_/__음성히스토리.txt", txt );
	}

	if( I.io.last_cr != fJSON.cr ) I.io.last_cr = fJSON.cr;

	++I.i;
	I.io = A[ I.i ];

	setTimeout( FN, 1 );
};
FN.lastAudio = null;
FN.tempFunc = function( e ){};
FN.tempObj = {};
FN.reqParam = { "onload" : FN.tempFunc, "onloadend" : FN.tempFunc };


//----------------------------------------------------------------------------------------------------;

FN( XHRS[ 0 ] );
FN( XHRS[ 1 ] );
FN( XHRS[ 2 ] );
FN( XHRS[ 3 ] );
FN( XHRS[ 4 ] );