/*/
E:\GitHub_Ttw--Stock\Ttw-Electron-Stock--NHN--Chart\전세계 - 지수\

/data/data/com.termux/files/home/Application/TtwService-Ruaend--StockCharts--IMG/WebPage/root/img/stock/charts---nhn
\\TTWDESKTOPU3\e\GitHub_Ttw--Base\TtwService-Ruaend--StockCharts--IMG\WebPage\root\img\stock\charts---nhn
//*/

//----------------------------------------------------------------------------------------------------;

global.REQUIRES = global.REQUIRES || {};

global.REQUIRES.fs = require( "fs" );
global.REQUIRES.url = require( "url" );

//----------------------------------------------------------------------------------------------------;

var FN_UPLOAD_IMG = (function(){
	var url = "http://thdtjsdn.com/upload__img?nm=";
	//var url = "http://localhost:49781/upload__img?nm=";
	var tempFunc = function( e ){
		if( FN_UPLOAD_IMG.arr_i == FN_UPLOAD_IMG.arr.length )
		{
			console.log( "[ COMPLETE ]" );
			return;
		}

		console.log( "[ FN_UPLOAD_IMG ] - " + FN_UPLOAD_IMG.arr.length + "/" + FN_UPLOAD_IMG.arr_i );

		++FN_UPLOAD_IMG.arr_i;
		setTimeout( FN_UPLOAD_IMG.arr_send, 1 );
	};
	var tempObj = {};
	var reqParam = { "onload" : tempFunc, "onloadend" : tempFunc };
	var fn = function( nm, bytearray ){
		SUtilXMLHttpReqPost.req__paramsStr( url + window.apis.uri.getURIReplaceSharp( nm ) , bytearray, tempObj, reqParam ); };
	return fn;
})();
FN_UPLOAD_IMG.arr = [];
FN_UPLOAD_IMG.arr_i = 0;
FN_UPLOAD_IMG.arr_send = function(){
	try
	{
		FN_UPLOAD_IMG( FN_UPLOAD_IMG.arr[ FN_UPLOAD_IMG.arr_i ][ 0 ], FN_UPLOAD_IMG.arr[ FN_UPLOAD_IMG.arr_i ][ 1 ] );
	}
	catch( er )
	{
		++FN_UPLOAD_IMG.arr_i;
		setTimeout( FN_UPLOAD_IMG.arr_send, 1 );
	}
};

var FN1 = function( url, nm ){ FN1.arr.push( [ url, nm ] ); };
	FN1.arr = [];
	FN1.arr_i = 0;

var FN2 = function(){
	if( FN1.arr_i == FN1.arr.length )
	{
		FN_UPLOAD_IMG.arr_send();
		console.log( "[ COMPLETE ]" );
		return;
	}

	console.log( "[ FN2 ] - " + FN1.arr.length + "/" + FN1.arr_i );

	var xhr = new XMLHttpRequest();
		xhr.responseType = "arraybuffer";
	var FN = function( url, nm ){ SUtilXMLHttpReqGetRef.req( xhr, url, {
		onloadend : function( e ){
			var res = e.target;
			var arrayBuffer = res.response;
			if( arrayBuffer )
				SUtilFsWriteStream.writeFile_Binary( "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--NHN--Chart/전세계 - 지수/" + FN1.arr[ FN1.arr_i ][ 1 ], new Buffer( arrayBuffer ) );
				//FN_UPLOAD_IMG.arr.push([ nm, arrayBuffer ]);

			++FN1.arr_i;
			setTimeout( FN2, 1 );
		}
		, onerror : function( e ){
			var res = e.target;
			var arrayBuffer = res.response;
			if( arrayBuffer )
				SUtilFsWriteStream.writeFile_Binary( "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--NHN--Chart/전세계 - 지수/" + FN1.arr[ FN1.arr_i ][ 1 ], new Buffer( arrayBuffer ) );
				//FN_UPLOAD_IMG.arr.push([ nm, arrayBuffer ]);

			++FN1.arr_i;
			setTimeout( FN2, 1 );
		}
	} ); };

	FN( FN1.arr[ FN1.arr_i ][ 0 ], FN1.arr[ FN1.arr_i ][ 1 ] );
};

//var FN2 = function(){
//	if( FN1.arr_i == FN1.arr.length )
//	{
//		//FN_UPLOAD_IMG.arr_send();
//		console.log( "[ COMPLETE ]" );
//		return;
//	}
//
//	console.log( "[ FN2 ] - " + FN1.arr.length + "/" + FN1.arr_i );
//
//	var url = new global.REQUIRES.url.URL( FN1.arr[ FN1.arr_i ][ 0 ] );
//	var p0_options = { host : url.host, port : url.port, path : url.pathname, headers : {} };
//	var param = { options : p0_options, cbFunctions : {
//			end : function( d ){
//
//				debugger;
//				//FN_UPLOAD_IMG.arr.push([ FN1.arr[ FN1.arr_i ][ 1 ], d ]);
//				SUtilFsWriteStream.writeFile_Binary( "E:/GitHub_Ttw--Stock/Ttw-Electron-Stock--NHN--Chart/전세계 - 지수/" + FN1.arr[ FN1.arr_i ][ 1 ], d );
//
////				try
////				{
////					FN_UPLOAD_IMG.arr.push([ nm, d ]);
////				}
////				catch( e )
////				{
////					++FN1.arr_i;
////					setTimeout( FN2, 1 );
////					return;
////				}
//
//				++FN1.arr_i;
//				setTimeout( FN2, 1 );
//			}
//			, error : function( d ){
//				++FN1.arr_i;
//				setTimeout( FN2, 1 );
//			}
//		}
//	};
//
//	try
//	{
//		SUtilHttp.request_GET__Binary( param );
//	}
//	catch( e )
//	{
//		return;
//	}
//};

//----------------------------------------------------------------------------------------------------;

var FN = function( p0, p1, p2 ){
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/mini/" + p0 + "_end_up_tablet.png"     , p1 + "-" + p2 + "-1일.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/candle/day/" + p0 + "_end.png"  , p1 + "-" + p2 + "-일봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/candle/week/" + p0 + "_end.png" , p1 + "-" + p2 + "-주봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/candle/month/" + p0 + "_end.png", p1 + "-" + p2 + "-월봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/area/month3/" + p0 + "_end.png" , p1 + "-" + p2 + "-3월.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/area/year/" + p0 + "_end.png"   , p1 + "-" + p2 + "-1년.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/area/year3/" + p0 + "_end.png"  , p1 + "-" + p2 + "-3년.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/area/year10/" + p0 + "_end.png" , p1 + "-" + p2 + "-10년.png" );
};

FN( "KOSPI", "한국", "코스피" );
FN( "KOSDAQ", "한국", "코스닥" );
FN( "KPI200", "한국", "코스피 200" );
FN( "FUT" , "한국", "코스피 200 선물" );

//16개;

//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;
//----------------------------------------------------------------------------------------------------;

//8개 * 27 = 216개;
var FN = function( p0, p1, p2 ){
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/day/" + p0 + "_end.png"         , p1 + "-" + p2 + "-1일.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/candle/day/" + p0 + "_end.png"  , p1 + "-" + p2 + "-일봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/candle/week/" + p0 + "_end.png" , p1 + "-" + p2 + "-주봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/candle/month/" + p0 + "_end.png", p1 + "-" + p2 + "-월봉.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/area/month3/" + p0 + "_end.png" , p1 + "-" + p2 + "-3월.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/area/year/" + p0 + "_end.png"   , p1 + "-" + p2 + "-1년.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/area/year3/" + p0 + "_end.png"  , p1 + "-" + p2 + "-3년.png" );
	FN1( "https://ssl.pstatic.net/imgfinance/chart/mobile/world/area/year10/" + p0 + "_end.png" , p1 + "-" + p2 + "-10년.png" );
};

FN( ".DJI" , "미국", "다우존스" );
FN( ".IXIC", "미국", "나스닥종합" );
FN( ".INX" , "미국", "S&P 500" );
FN( ".SOX" , "미국", "필라델피아 반도체" );
FN( ".DJT" , "미국", "다우운송" );
FN( ".NDX" , "미국", "나스닥 100" );

FN( "SHS@000001", "중국", "상해종합" );
FN( ".SZSC"     , "중국", "심천종합" );
FN( "SHS@000002", "중국", "상해A" );
FN( ".SZSA"     , "중국", "심천A" );

FN( ".HSI" , "홍콩", "항셍" );
FN( ".HSCE", "홍콩", "홍콩H" );

FN( ".N225", "일본", "니케이 225" );
FN( ".TOPX", "일본", "토픽스" );

FN( ".VNI" , "베트남", "VN" );
FN( ".HNXI", "베트남", "하노이" );

FN( "TWS@TI01", "대만", "가권" );

FN( "MYI@KLSE", "말레이시아", "KLCI" );

FN( "IDI@JKSE", "인도네시아", "IDX종합" );

FN( "INI@BSE30", "인도", "SENSEX" );

FN( "STX@SX5E", "유럽", "유로스톡스 50" );

FN( "XTR@DAX30", "독일", "DAX 30" );

FN( "LNS@FTSE100", "영국", "FTSE 100" );

FN( "ITI@FTSEMIB", "이탈리아", "FTSE MIB" );

FN( "PAS@CAC40", "프랑스", "CAC 40" );

FN( "RUI@RTSI", "러시아", "RTSI" );

FN( "BRI@BVSP", "브라질", "BOVESPA" );


FN2();